// Online Examination System - Objective Question Bank & Exam Tracks
window.EXAM_TRACKS = [
  {
    id: "cs-core",
    title: "Computer Science Core",
    code: "CS301",
    subtitle: "DSA, Operating Systems, DBMS & Computer Networks",
    durationMinutes: 10,
    marksPerQuestion: 10,
    negativeMarking: 0,
    passPercentage: 50,
    color: 0x38bdf8,
    accentHex: "#38bdf8",
    geometryType: "icosahedron",
    questions: [
      {
        id: 1,
        topic: "Data Structures",
        difficulty: "Easy",
        question: "What is the worst-case time complexity of searching for an element in a balanced Binary Search Tree (AVL Tree) with n nodes?",
        options: ["O(1)", "O(log n)", "O(n)", "O(n log n)"],
        correctIndex: 1,
        explanation: "An AVL tree is height-balanced with height h = O(log n), so lookup traverses at most O(log n) levels even in the worst case."
      },
      {
        id: 2,
        topic: "Operating Systems",
        difficulty: "Medium",
        question: "Which of the following page replacement algorithms suffers from Belady's Anomaly?",
        options: ["Least Recently Used (LRU)", "Optimal Page Replacement", "First-In First-Out (FIFO)", "Least Frequently Used (LFU) with stack property"],
        correctIndex: 2,
        explanation: "FIFO page replacement does not satisfy the stack property, so increasing the number of page frames can paradoxically increase page faults (Belady's Anomaly)."
      },
      {
        id: 3,
        topic: "DBMS",
        difficulty: "Medium",
        question: "A relation R is in Boyce-Codd Normal Form (BCNF) if and only if for every non-trivial functional dependency X → Y:",
        options: [
          "Y is a prime attribute",
          "X is a superkey of R",
          "No transitive dependency exists on non-prime attributes",
          "Every attribute is atomic"
        ],
        correctIndex: 1,
        explanation: "BCNF is a stricter version of 3NF requiring that for every non-trivial functional dependency X → Y, the determinant X must be a superkey."
      },
      {
        id: 4,
        topic: "Computer Networks",
        difficulty: "Easy",
        question: "At which layer of the OSI model does the TCP protocol operate to provide reliable, connection-oriented data delivery?",
        options: ["Network Layer", "Data Link Layer", "Transport Layer", "Session Layer"],
        correctIndex: 2,
        explanation: "TCP (Transmission Control Protocol) operates at Layer 4 (Transport Layer), handling end-to-end flow control, segmentation, and error recovery."
      },
      {
        id: 5,
        topic: "Data Structures",
        difficulty: "Medium",
        question: "Which data structure is used internally by Breadth-First Search (BFS) traversal of a graph?",
        options: ["Stack", "Queue", "Min-Heap", "Hash Table"],
        correctIndex: 1,
        explanation: "BFS explores vertices level by level in FIFO order, which requires a Queue to track discovered vertices awaiting exploration."
      },
      {
        id: 6,
        topic: "Operating Systems",
        difficulty: "Hard",
        question: "Which of the following is NOT one of Coffman's four necessary conditions for a deadlock to occur?",
        options: ["Mutual Exclusion", "Hold and Wait", "Preemption", "Circular Wait"],
        correctIndex: 2,
        explanation: "Coffman's four conditions are Mutual Exclusion, Hold and Wait, NO Preemption, and Circular Wait. Allowing preemption actually prevents deadlock."
      },
      {
        id: 7,
        topic: "DBMS",
        difficulty: "Easy",
        question: "Which ACID property ensures that once a database transaction commits, its changes persist even in the event of a system crash?",
        options: ["Atomicity", "Consistency", "Isolation", "Durability"],
        correctIndex: 3,
        explanation: "Durability guarantees that committed changes are written to non-volatile storage (such as write-ahead logs) and survive power loss or crashes."
      },
      {
        id: 8,
        topic: "Algorithms",
        difficulty: "Medium",
        question: "Which algorithmic paradigm is used by Dijkstra's single-source shortest path algorithm?",
        options: ["Divide and Conquer", "Greedy Approach", "Backtracking", "Branch and Bound"],
        correctIndex: 1,
        explanation: "Dijkstra's algorithm repeatedly selects the unvisited vertex with the smallest tentative distance, which is the hallmark of the Greedy strategy."
      },
      {
        id: 9,
        topic: "Computer Networks",
        difficulty: "Medium",
        question: "What is the size of an IPv6 address in bits?",
        options: ["32 bits", "48 bits", "64 bits", "128 bits"],
        correctIndex: 3,
        explanation: "IPv4 uses 32-bit addresses, MAC addresses use 48 bits, and IPv6 uses 128-bit addresses represented as eight 16-bit hexadecimal groups."
      },
      {
        id: 10,
        topic: "Data Structures",
        difficulty: "Hard",
        question: "In a binary max-heap containing n elements, what is the time complexity of building the heap bottom-up using Floyd's algorithm?",
        options: ["O(n)", "O(n log n)", "O(log n)", "O(n²)"],
        correctIndex: 0,
        explanation: "Bottom-up heapify (Floyd's build-heap) runs in linear O(n) time because most nodes reside near the bottom of the tree and travel very few levels."
      }
    ]
  },
  {
    id: "web-3d",
    title: "Web Tech & Three.js 3D Graphics",
    code: "WT402",
    subtitle: "HTML5, Modern ES6+, WebGL Pipeline & Three.js Engine",
    durationMinutes: 8,
    marksPerQuestion: 10,
    negativeMarking: 0,
    passPercentage: 50,
    color: 0xa855f7,
    accentHex: "#a855f7",
    geometryType: "octahedron",
    questions: [
      {
        id: 1,
        topic: "Three.js Core",
        difficulty: "Easy",
        question: "Which three core objects are strictly required in Three.js to render any 3D visual onto the screen?",
        options: [
          "Mesh, Texture, and Light",
          "Scene, Camera, and Renderer",
          "Geometry, Shader, and Canvas",
          "Vector3, Matrix4, and Raycaster"
        ],
        correctIndex: 1,
        explanation: "Every Three.js application requires a Scene (container for objects), a Camera (point of view), and a WebGLRenderer (draws the scene view onto a canvas)."
      },
      {
        id: 2,
        topic: "Three.js Objects",
        difficulty: "Easy",
        question: "In Three.js, a THREE.Mesh is constructed by combining which two components?",
        options: [
          "Geometry and Material",
          "Scene and Light",
          "Texture and Camera",
          "BufferAttribute and Uniform"
        ],
        correctIndex: 0,
        explanation: "A THREE.Mesh takes a Geometry (defining vertices and faces) and a Material (defining surface shading, color, and textures)."
      },
      {
        id: 3,
        topic: "Three.js Interaction",
        difficulty: "Medium",
        question: "Which Three.js class is used to detect mouse clicks and hover intersections with 3D objects in world space?",
        options: [
          "THREE.OrbitControls",
          "THREE.Raycaster",
          "THREE.Box3",
          "THREE.Frustum"
        ],
        correctIndex: 1,
        explanation: "THREE.Raycaster casts a 3D ray from the camera through normalized device coordinates of the mouse pointer to find intersecting 3D meshes."
      },
      {
        id: 4,
        topic: "Web Animation",
        difficulty: "Easy",
        question: "Which browser API is recommended for driving a smooth 60 FPS render loop in Three.js and stops automatically when the browser tab is inactive?",
        options: [
          "setInterval()",
          "setTimeout()",
          "requestAnimationFrame()",
          "Promise.resolve()"
        ],
        correctIndex: 2,
        explanation: "window.requestAnimationFrame() synchronizes rendering with the display refresh rate and pauses in background tabs to save GPU/CPU power."
      },
      {
        id: 5,
        topic: "Three.js Materials",
        difficulty: "Medium",
        question: "Which Three.js material DOES NOT react to scene lights and always renders at full brightness?",
        options: [
          "THREE.MeshStandardMaterial",
          "THREE.MeshPhongMaterial",
          "THREE.MeshBasicMaterial",
          "THREE.MeshPhysicalMaterial"
        ],
        correctIndex: 2,
        explanation: "MeshBasicMaterial is an unlit material whose color or wireframe is drawn directly without computing lighting or shadows."
      },
      {
        id: 6,
        topic: "JavaScript ES6+",
        difficulty: "Medium",
        question: "What does the 'async' keyword before a JavaScript function declaration guarantee about its return value?",
        options: [
          "It runs on a separate OS thread",
          "It always returns a Promise",
          "It blocks the main thread until completion",
          "It caches the result in localStorage"
        ],
        correctIndex: 1,
        explanation: "An async function always wraps its return value in a Promise (or returns a Promise directly), enabling clean 'await' syntax."
      },
      {
        id: 7,
        topic: "Three.js Coordinates",
        difficulty: "Hard",
        question: "When converting 2D mouse coordinates (clientX, clientY) for THREE.Raycaster, what is the range of Normalized Device Coordinates (NDC) for X and Y?",
        options: [
          "0 to 1",
          "-1 to +1",
          "0 to window.innerWidth",
          "-180 to +180"
        ],
        correctIndex: 1,
        explanation: "WebGL and THREE.Raycaster expect Normalized Device Coordinates (NDC) ranging from -1 (left/bottom) to +1 (right/top)."
      },
      {
        id: 8,
        topic: "Web Storage",
        difficulty: "Easy",
        question: "Which browser storage mechanism persists key-value data across browser restarts with no expiration time?",
        options: [
          "sessionStorage",
          "localStorage",
          "Memory Heap",
          "window.name"
        ],
        correctIndex: 1,
        explanation: "localStorage persists data on disk across browser sessions until explicitly cleared by the application or user."
      }
    ]
  },
  {
    id: "ai-ds",
    title: "AI & Machine Learning",
    code: "AI504",
    subtitle: "Search Heuristics, Neural Networks & Evaluation Metrics",
    durationMinutes: 8,
    marksPerQuestion: 10,
    negativeMarking: 0,
    passPercentage: 50,
    color: 0x10b981,
    accentHex: "#10b981",
    geometryType: "torusKnot",
    questions: [
      {
        id: 1,
        topic: "Search Algorithms",
        difficulty: "Easy",
        question: "In A* search, the evaluation function f(n) = g(n) + h(n) guarantees an optimal solution if the heuristic h(n) is:",
        options: [
          "Always greater than the true cost",
          "Admissible (never overestimates the true cost to reach the goal)",
          "Randomly initialized",
          "Exponential in branching factor"
        ],
        correctIndex: 1,
        explanation: "An admissible heuristic never overestimates the actual cost to reach the goal, ensuring A* finds the optimal shortest path."
      },
      {
        id: 2,
        topic: "Machine Learning",
        difficulty: "Easy",
        question: "When a machine learning model achieves 99% accuracy on training data but only 62% accuracy on unseen test data, the model is suffering from:",
        options: ["Underfitting", "Overfitting", "Vanishing Gradients", "Data Normalization"],
        correctIndex: 1,
        explanation: "High training accuracy coupled with poor generalization on unseen test data is the classic symptom of overfitting (high variance)."
      },
      {
        id: 3,
        topic: "Deep Learning",
        difficulty: "Medium",
        question: "Which activation function is defined as f(x) = max(0, x) and helps mitigate the vanishing gradient problem in deep neural networks?",
        options: ["Sigmoid", "Hyperbolic Tangent (tanh)", "ReLU (Rectified Linear Unit)", "Softmax"],
        correctIndex: 2,
        explanation: "ReLU outputs max(0, x) with a constant gradient of 1 for positive inputs, preventing exponential gradient decay across deep layers."
      },
      {
        id: 4,
        topic: "Evaluation Metrics",
        difficulty: "Medium",
        question: "The harmonic mean of Precision and Recall is known as:",
        options: ["ROC-AUC Score", "F1-Score", "Mean Squared Error", "Confusion Ratio"],
        correctIndex: 1,
        explanation: "F1-Score = 2 * (Precision * Recall) / (Precision + Recall), providing a balanced metric especially on imbalanced datasets."
      },
      {
        id: 5,
        topic: "Unsupervised Learning",
        difficulty: "Easy",
        question: "Which of the following is an unsupervised clustering algorithm?",
        options: ["Logistic Regression", "Support Vector Machine (SVM)", "K-Means Clustering", "Random Forest Classifier"],
        correctIndex: 2,
        explanation: "K-Means partitions unlabeled data points into K clusters by iteratively updating cluster centroids without ground-truth labels."
      },
      {
        id: 6,
        topic: "Neural Networks",
        difficulty: "Medium",
        question: "Which algorithm computes the gradient of the loss function with respect to each weight by applying the chain rule from output to input layers?",
        options: ["Backpropagation", "Minimax Alpha-Beta Pruning", "K-Fold Cross Validation", "Principal Component Analysis"],
        correctIndex: 0,
        explanation: "Backpropagation efficiently applies the chain rule of calculus backward through the network graph to compute weight gradients."
      }
    ]
  },
  {
    id: "quick-viva",
    title: "Quick Viva Sprint (Demo)",
    code: "MP101",
    subtitle: "5 Rapid Objective Questions — Ideal for Live Miniproject Demo",
    durationMinutes: 3,
    marksPerQuestion: 20,
    negativeMarking: 0,
    passPercentage: 40,
    color: 0xf59e0b,
    accentHex: "#f59e0b",
    geometryType: "dodecahedron",
    questions: [
      {
        id: 1,
        topic: "System Architecture",
        difficulty: "Easy",
        question: "In an Online Examination System, why is client-side timer state synchronized with an automated submission handler?",
        options: [
          "To increase network bandwidth usage",
          "To ensure exams are automatically submitted and evaluated when the allotted time expires",
          "To disable CSS rendering",
          "To prevent objective question randomization"
        ],
        correctIndex: 1,
        explanation: "Automated timeout submission guarantees fairness by locking and grading all saved responses the instant the countdown reaches 00:00."
      },
      {
        id: 2,
        topic: "3D Visualization",
        difficulty: "Easy",
        question: "Which WebGL-powered JavaScript library is used in this project to render interactive 3D question nodes and spatial analytics?",
        options: ["jQuery UI", "Three.js", "Bootstrap", "Lodash"],
        correctIndex: 1,
        explanation: "Three.js is a 3D graphics library built on top of WebGL for rendering interactive 3D scenes, geometries, lights, and raycasted controls."
      },
      {
        id: 3,
        topic: "Data Structures",
        difficulty: "Easy",
        question: "What is the time complexity of looking up a student's selected option for question index 'i' in an array or hash map during automated grading?",
        options: ["O(1)", "O(n²)", "O(2^n)", "O(n!)"],
        correctIndex: 0,
        explanation: "Direct index or key lookup in an array/map takes constant O(1) time per question, making total evaluation O(N) for N questions."
      },
      {
        id: 4,
        topic: "Database & Storage",
        difficulty: "Easy",
        question: "Which format is used to serialize student attempt records and custom questions into browser storage?",
        options: ["JSON (JavaScript Object Notation)", "Binary EXE", "MP4 Stream", "SMTP Packet"],
        correctIndex: 0,
        explanation: "JSON.stringify() and JSON.parse() serialize structured JavaScript objects cleanly for storage and export."
      },
      {
        id: 5,
        topic: "HTTP & Web",
        difficulty: "Easy",
        question: "Which HTTP status code indicates a successful GET or POST request in a web application?",
        options: ["200 OK", "404 Not Found", "500 Internal Server Error", "301 Moved Permanently"],
        correctIndex: 0,
        explanation: "HTTP 200 OK indicates that the request has succeeded."
      }
    ]
  }
];
