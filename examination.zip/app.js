// Online Examination System — Interactive Three.js 3D Engine & Exam Controller
(function () {
  const STORAGE_KEYS = {
    STUDENT: "oes_current_student_v1",
    ATTEMPTS: "oes_exam_attempts_v1",
    CUSTOM_QUESTIONS: "oes_custom_questions_v1"
  };

  // Merge any faculty-added custom questions into EXAM_TRACKS
  function loadCustomQuestions() {
    try {
      const raw = localStorage.getItem(STORAGE_KEYS.CUSTOM_QUESTIONS);
      if (!raw) return;
      const customMap = JSON.parse(raw);
      window.EXAM_TRACKS.forEach((track) => {
        if (Array.isArray(customMap[track.id])) {
          customMap[track.id].forEach((q) => {
            if (!track.questions.some((existing) => existing.id === q.id)) {
              track.questions.push(q);
            }
          });
        }
      });
    } catch (e) {
      console.warn("Could not load custom questions:", e);
    }
  }
  loadCustomQuestions();

  // Application State
  const state = {
    view: "login", // 'login' | 'dashboard' | 'exam' | 'results'
    student: null,
    selectedTrackId: "cs-core",
    activeTrack: null,
    currentQuestionIndex: 0,
    answers: {}, // { questionIndex: selectedOptionIndex }
    flagged: {}, // { questionIndex: boolean }
    visited: {}, // { questionIndex: boolean }
    remainingSeconds: 0,
    totalSeconds: 0,
    timerInterval: null,
    isPaused: false,
    tabSwitches: 0,
    examStartTime: null,
    lastResult: null
  };

  // =========================================================================
  // THREE.JS INTERACTIVE 3D SCENE CONTROLLER
  // =========================================================================
  const ThreeStage = {
    scene: null,
    camera: null,
    renderer: null,
    raycaster: null,
    mouse: { x: 0, y: 0, normX: 0, normY: 0 },
    targetCameraPos: { x: 0, y: 2, z: 18 },
    targetLookAt: { x: 0, y: 0, z: 0 },
    currentLookAt: { x: 0, y: 0, z: 0 },
    coreGroup: null,
    questionNodesGroup: null,
    trackNodesGroup: null,
    resultBarsGroup: null,
    timerRingMesh: null,
    starField: null,
    interactiveMeshes: [],
    hoveredMesh: null,
    clock: null,
    fallback2D: false,

    init() {
      const container = document.getElementById("three-canvas-container");
      if (typeof THREE === "undefined") {
        this.initFallbackCanvas(container);
        return;
      }

      try {
        this.clock = new THREE.Clock();
        this.scene = new THREE.Scene();
        this.scene.fog = new THREE.FogExp2(0x060913, 0.022);

        this.camera = new THREE.PerspectiveCamera(
          55,
          window.innerWidth / window.innerHeight,
          0.1,
          200
        );
        this.camera.position.set(0, 2, 18);

        this.renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
        this.renderer.setSize(window.innerWidth, window.innerHeight);
        this.renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
        container.innerHTML = "";
        container.appendChild(this.renderer.domElement);

        this.raycaster = new THREE.Raycaster();

        // Lights
        const ambientLight = new THREE.AmbientLight(0x94a3b8, 0.75);
        this.scene.add(ambientLight);

        const dirLight1 = new THREE.DirectionalLight(0x38bdf8, 1.4);
        dirLight1.position.set(12, 18, 15);
        this.scene.add(dirLight1);

        const pointLight = new THREE.PointLight(0xa855f7, 1.6, 45);
        pointLight.position.set(-10, -6, 8);
        this.scene.add(pointLight);

        // Groups
        this.coreGroup = new THREE.Group();
        this.questionNodesGroup = new THREE.Group();
        this.trackNodesGroup = new THREE.Group();
        this.resultBarsGroup = new THREE.Group();

        this.scene.add(this.coreGroup);
        this.scene.add(this.questionNodesGroup);
        this.scene.add(this.trackNodesGroup);
        this.scene.add(this.resultBarsGroup);

        this.buildCyberCore();
        this.buildStarField();
        this.buildTrackCarousel();

        // Events
        window.addEventListener("resize", () => this.onResize());
        window.addEventListener("mousemove", (e) => this.onPointerMove(e));
        window.addEventListener("click", (e) => this.onPointerClick(e));

        this.animate();
      } catch (err) {
        console.warn("WebGL fallback activated:", err);
        this.initFallbackCanvas(container);
      }
    },

    buildCyberCore() {
      // Central wireframe knowledge icosahedron
      const geo = new THREE.IcosahedronGeometry(2.3, 1);
      const mat = new THREE.MeshStandardMaterial({
        color: 0x38bdf8,
        emissive: 0x075985,
        emissiveIntensity: 0.55,
        wireframe: true
      });
      const coreMesh = new THREE.Mesh(geo, mat);
      coreMesh.name = "cyberCore";
      this.coreGroup.add(coreMesh);

      // Inner glowing sphere
      const innerGeo = new THREE.SphereGeometry(1.35, 24, 24);
      const innerMat = new THREE.MeshBasicMaterial({
        color: 0x38bdf8,
        transparent: true,
        opacity: 0.22
      });
      const innerSphere = new THREE.Mesh(innerGeo, innerMat);
      this.coreGroup.add(innerSphere);

      // 3D Chrono Timer Ring around the core
      const ringGeo = new THREE.TorusGeometry(3.4, 0.08, 16, 100);
      const ringMat = new THREE.MeshBasicMaterial({
        color: 0x38bdf8,
        transparent: true,
        opacity: 0.65
      });
      this.timerRingMesh = new THREE.Mesh(ringGeo, ringMat);
      this.timerRingMesh.rotation.x = Math.PI / 2.6;
      this.coreGroup.add(this.timerRingMesh);
    },

    buildStarField() {
      const count = 900;
      const positions = new Float32Array(count * 3);
      for (let i = 0; i < count * 3; i += 3) {
        positions[i] = (Math.random() - 0.5) * 90;
        positions[i + 1] = (Math.random() - 0.5) * 60;
        positions[i + 2] = (Math.random() - 0.5) * 70 - 10;
      }
      const geo = new THREE.BufferGeometry();
      geo.setAttribute("position", new THREE.BufferAttribute(positions, 3));
      const mat = new THREE.PointsMaterial({
        color: 0x7dd3fc,
        size: 0.16,
        transparent: true,
        opacity: 0.65
      });
      this.starField = new THREE.Points(geo, mat);
      this.scene.add(this.starField);
    },

    buildTrackCarousel() {
      this.clearGroup(this.trackNodesGroup);
      const tracks = window.EXAM_TRACKS;
      const radius = 6.8;

      tracks.forEach((track, idx) => {
        const angle = (idx / tracks.length) * Math.PI * 2;
        let geo;
        if (track.geometryType === "octahedron") {
          geo = new THREE.OctahedronGeometry(1.05, 0);
        } else if (track.geometryType === "torusKnot") {
          geo = new THREE.TorusKnotGeometry(0.65, 0.2, 48, 12);
        } else if (track.geometryType === "dodecahedron") {
          geo = new THREE.DodecahedronGeometry(0.95, 0);
        } else {
          geo = new THREE.IcosahedronGeometry(0.95, 0);
        }

        const mat = new THREE.MeshStandardMaterial({
          color: track.color,
          emissive: track.color,
          emissiveIntensity: 0.28,
          roughness: 0.25,
          metalness: 0.6
        });

        const mesh = new THREE.Mesh(geo, mat);
        mesh.position.set(
          Math.cos(angle) * radius,
          Math.sin(angle * 2) * 0.8,
          Math.sin(angle) * radius
        );
        mesh.userData = {
          type: "trackNode",
          trackId: track.id,
          label: `${track.code}: ${track.title} (Click to select)`
        };

        this.trackNodesGroup.add(mesh);
      });
    },

    buildExamQuestionNodes(track) {
      if (this.fallback2D || !this.scene) return;
      this.clearGroup(this.questionNodesGroup);
      const total = track.questions.length;
      const arcRadius = 8.2;

      track.questions.forEach((q, idx) => {
        // Arrange question nodes in a dramatic 3D semi-circular orbital arc in front of the camera
        const t = total === 1 ? 0.5 : idx / (total - 1);
        const angle = (t - 0.5) * Math.PI * 0.95; // spread across front view
        const x = Math.sin(angle) * arcRadius;
        const y = Math.cos(angle * 2) * 1.4 + 2.5;
        const z = -Math.cos(angle) * 3.5 + 2.5;

        const geo = new THREE.OctahedronGeometry(0.58, 0);
        const mat = new THREE.MeshStandardMaterial({
          color: 0x64748b,
          emissive: 0x1e293b,
          emissiveIntensity: 0.4,
          roughness: 0.2,
          metalness: 0.7
        });

        const mesh = new THREE.Mesh(geo, mat);
        mesh.position.set(x, y, z);

        // Outer wireframe halo
        const haloGeo = new THREE.IcosahedronGeometry(0.82, 0);
        const haloMat = new THREE.MeshBasicMaterial({
          color: 0x38bdf8,
          wireframe: true,
          transparent: true,
          opacity: 0.25
        });
        const halo = new THREE.Mesh(haloGeo, haloMat);
        mesh.add(halo);

        mesh.userData = {
          type: "questionNode",
          questionIndex: idx,
          halo: halo,
          baseY: y,
          label: `Q${idx + 1}: ${q.topic} (${q.difficulty})`
        };

        this.questionNodesGroup.add(mesh);
      });

      this.syncQuestionNodeColors();
    },

    syncQuestionNodeColors() {
      if (this.fallback2D || !this.questionNodesGroup) return;
      this.questionNodesGroup.children.forEach((mesh, idx) => {
        const isCurrent = idx === state.currentQuestionIndex;
        const isAnswered = state.answers[idx] !== undefined;
        const isFlagged = !!state.flagged[idx];

        let colorHex = 0x64748b; // unvisited slate
        let emissiveHex = 0x1e293b;

        if (isFlagged) {
          colorHex = 0xf59e0b; // amber review
          emissiveHex = 0x92400e;
        } else if (isAnswered) {
          colorHex = 0x10b981; // emerald answered
          emissiveHex = 0x065f46;
        } else if (state.visited[idx]) {
          colorHex = 0x94a3b8;
          emissiveHex = 0x334155;
        }

        if (isCurrent) {
          emissiveHex = 0x0284c7;
        }

        mesh.material.color.setHex(colorHex);
        mesh.material.emissive.setHex(emissiveHex);
        mesh.scale.setScalar(isCurrent ? 1.45 : 1.0);

        if (mesh.userData.halo) {
          mesh.userData.halo.material.color.setHex(
            isCurrent ? 0x38bdf8 : isFlagged ? 0xf59e0b : isAnswered ? 0x10b981 : 0x475569
          );
          mesh.userData.halo.material.opacity = isCurrent ? 0.9 : 0.3;
        }
      });
    },

    buildResults3DBars(result) {
      if (this.fallback2D || !this.scene) return;
      this.clearGroup(this.resultBarsGroup);

      const bars = [
        { label: "Correct", value: result.correctCount, max: result.totalQuestions, color: 0x10b981, x: -3.2 },
        { label: "Wrong", value: result.wrongCount, max: result.totalQuestions, color: 0xef4444, x: 0 },
        { label: "Skipped", value: result.unansweredCount, max: result.totalQuestions, color: 0xf59e0b, x: 3.2 }
      ];

      bars.forEach((b) => {
        const ratio = Math.max(0.15, (b.value / Math.max(1, b.max)) * 5.5);
        const geo = new THREE.BoxGeometry(1.3, ratio, 1.3);
        const mat = new THREE.MeshStandardMaterial({
          color: b.color,
          emissive: b.color,
          emissiveIntensity: 0.35,
          roughness: 0.25,
          metalness: 0.5
        });
        const mesh = new THREE.Mesh(geo, mat);
        mesh.position.set(b.x, ratio / 2 - 2.2, 2.5);
        mesh.userData = {
          type: "resultBar",
          label: `${b.label}: ${b.value} / ${b.max} questions`
        };
        this.resultBarsGroup.add(mesh);
      });
    },

    setStageMode(mode) {
      if (this.fallback2D || !this.scene) return;
      if (mode === "login") {
        this.trackNodesGroup.visible = true;
        this.questionNodesGroup.visible = false;
        this.resultBarsGroup.visible = false;
        this.coreGroup.visible = true;
        this.targetCameraPos = { x: 0, y: 2.2, z: 16 };
        this.targetLookAt = { x: 0, y: 0, z: 0 };
      } else if (mode === "dashboard") {
        this.trackNodesGroup.visible = true;
        this.questionNodesGroup.visible = false;
        this.resultBarsGroup.visible = false;
        this.coreGroup.visible = true;
        this.targetCameraPos = { x: 0, y: 3.5, z: 14 };
        this.targetLookAt = { x: 0, y: 0, z: 0 };
      } else if (mode === "exam") {
        this.trackNodesGroup.visible = false;
        this.questionNodesGroup.visible = true;
        this.resultBarsGroup.visible = false;
        this.coreGroup.visible = true;
        this.targetCameraPos = { x: 0, y: 1.8, z: 12.5 };
        this.targetLookAt = { x: 0, y: 1.5, z: 0 };
      } else if (mode === "results") {
        this.trackNodesGroup.visible = false;
        this.questionNodesGroup.visible = false;
        this.resultBarsGroup.visible = true;
        this.coreGroup.visible = true;
        this.targetCameraPos = { x: 0, y: 2.0, z: 13.5 };
        this.targetLookAt = { x: 0, y: 0.5, z: 0 };
      }
    },

    updateTimerVisual(remaining, total) {
      if (this.fallback2D || !this.timerRingMesh) return;
      const ratio = total > 0 ? remaining / total : 1;
      if (ratio <= 0.2) {
        this.timerRingMesh.material.color.setHex(0xef4444);
      } else if (ratio <= 0.5) {
        this.timerRingMesh.material.color.setHex(0xf59e0b);
      } else {
        this.timerRingMesh.material.color.setHex(0x38bdf8);
      }
      this.timerRingMesh.scale.setScalar(0.85 + ratio * 0.25);
    },

    clearGroup(group) {
      if (!group) return;
      while (group.children.length > 0) {
        const child = group.children[0];
        group.remove(child);
      }
    },

    onResize() {
      if (this.fallback2D || !this.renderer) return;
      this.camera.aspect = window.innerWidth / window.innerHeight;
      this.camera.updateProjectionMatrix();
      this.renderer.setSize(window.innerWidth, window.innerHeight);
    },

    onPointerMove(e) {
      this.mouse.x = e.clientX;
      this.mouse.y = e.clientY;
      this.mouse.normX = (e.clientX / window.innerWidth) * 2 - 1;
      this.mouse.normY = -(e.clientY / window.innerHeight) * 2 + 1;

      if (this.fallback2D || !this.raycaster) return;

      // Avoid raycasting through solid UI cards when hovered over interactive form controls
      const targetEl = e.target;
      const isOverCanvas = targetEl && targetEl.tagName === "CANVAS";
      const tooltip = document.getElementById("node-tooltip");

      if (!isOverCanvas) {
        if (tooltip) tooltip.style.opacity = "0";
        this.hoveredMesh = null;
        document.body.style.cursor = "default";
        return;
      }

      this.raycaster.setFromCamera(
        { x: this.mouse.normX, y: this.mouse.normY },
        this.camera
      );

      const candidates = [];
      if (this.questionNodesGroup.visible) {
        candidates.push(...this.questionNodesGroup.children);
      }
      if (this.trackNodesGroup.visible) {
        candidates.push(...this.trackNodesGroup.children);
      }
      if (this.resultBarsGroup.visible) {
        candidates.push(...this.resultBarsGroup.children);
      }

      const intersects = this.raycaster.intersectObjects(candidates, false);
      if (intersects.length > 0) {
        const hit = intersects[0].object;
        this.hoveredMesh = hit;
        document.body.style.cursor = "pointer";
        if (tooltip && hit.userData && hit.userData.label) {
          tooltip.textContent = hit.userData.label;
          tooltip.style.left = `${e.clientX}px`;
          tooltip.style.top = `${e.clientY}px`;
          tooltip.style.opacity = "1";
        }
      } else {
        this.hoveredMesh = null;
        document.body.style.cursor = "default";
        if (tooltip) tooltip.style.opacity = "0";
      }
    },

    onPointerClick(e) {
      if (this.fallback2D || !this.hoveredMesh) return;
      if (!e.target || e.target.tagName !== "CANVAS") return;

      const data = this.hoveredMesh.userData;
      if (!data) return;

      if (data.type === "questionNode" && state.view === "exam") {
        ExamApp.goToQuestion(data.questionIndex);
      } else if (data.type === "trackNode" && state.view === "dashboard") {
        ExamApp.selectTrack(data.trackId);
      }
    },

    animate() {
      if (this.fallback2D) return;
      requestAnimationFrame(() => this.animate());

      const elapsed = this.clock.getElapsedTime();

      // Rotate central core
      if (this.coreGroup) {
        this.coreGroup.rotation.y = elapsed * 0.32;
        this.coreGroup.rotation.z = Math.sin(elapsed * 0.4) * 0.15;
      }

      // Rotate starfield gently
      if (this.starField) {
        this.starField.rotation.y = elapsed * 0.03;
      }

      // Orbit track nodes
      if (this.trackNodesGroup && this.trackNodesGroup.visible) {
        this.trackNodesGroup.rotation.y = elapsed * 0.22;
        this.trackNodesGroup.children.forEach((mesh, idx) => {
          mesh.rotation.x = elapsed * 0.8 + idx;
          mesh.rotation.y = elapsed * 0.6;
          const isSelected = mesh.userData.trackId === state.selectedTrackId;
          mesh.scale.setScalar(isSelected ? 1.35 + Math.sin(elapsed * 4) * 0.08 : 1.0);
        });
      }

      // Animate 3D exam question nodes
      if (this.questionNodesGroup && this.questionNodesGroup.visible) {
        this.questionNodesGroup.children.forEach((mesh, idx) => {
          mesh.rotation.y = elapsed * 0.9 + idx * 0.5;
          mesh.rotation.x = elapsed * 0.4;
          mesh.position.y =
            mesh.userData.baseY + Math.sin(elapsed * 2.2 + idx) * 0.18;
        });
      }

      // Subtle mouse parallax on camera
      const parallaxX = this.mouse.normX * 1.1;
      const parallaxY = this.mouse.normY * 0.65;

      this.camera.position.x +=
        (this.targetCameraPos.x + parallaxX - this.camera.position.x) * 0.05;
      this.camera.position.y +=
        (this.targetCameraPos.y + parallaxY - this.camera.position.y) * 0.05;
      this.camera.position.z +=
        (this.targetCameraPos.z - this.camera.position.z) * 0.05;

      this.currentLookAt.x += (this.targetLookAt.x - this.currentLookAt.x) * 0.06;
      this.currentLookAt.y += (this.targetLookAt.y - this.currentLookAt.y) * 0.06;
      this.currentLookAt.z += (this.targetLookAt.z - this.currentLookAt.z) * 0.06;

      this.camera.lookAt(
        this.currentLookAt.x,
        this.currentLookAt.y,
        this.currentLookAt.z
      );

      this.renderer.render(this.scene, this.camera);
    },

    initFallbackCanvas(container) {
      this.fallback2D = true;
      const canvas = document.createElement("canvas");
      container.innerHTML = "";
      container.appendChild(canvas);
      const ctx = canvas.getContext("2d");
      const resize = () => {
        canvas.width = window.innerWidth;
        canvas.height = window.innerHeight;
      };
      resize();
      window.addEventListener("resize", resize);

      const nodes = Array.from({ length: 45 }, () => ({
        x: Math.random() * canvas.width,
        y: Math.random() * canvas.height,
        vx: (Math.random() - 0.5) * 0.7,
        vy: (Math.random() - 0.5) * 0.7,
        r: Math.random() * 2.5 + 1.5
      }));

      const draw = () => {
        ctx.fillStyle = "#060913";
        ctx.fillRect(0, 0, canvas.width, canvas.height);
        nodes.forEach((n, i) => {
          n.x += n.vx;
          n.y += n.vy;
          if (n.x < 0 || n.x > canvas.width) n.vx *= -1;
          if (n.y < 0 || n.y > canvas.height) n.vy *= -1;
          ctx.beginPath();
          ctx.arc(n.x, n.y, n.r, 0, Math.PI * 2);
          ctx.fillStyle = "#38bdf8";
          ctx.fill();
          for (let j = i + 1; j < nodes.length; j++) {
            const dx = n.x - nodes[j].x;
            const dy = n.y - nodes[j].y;
            const dist = Math.hypot(dx, dy);
            if (dist < 150) {
              ctx.strokeStyle = `rgba(56, 189, 248, ${1 - dist / 150})`;
              ctx.lineWidth = 0.6;
              ctx.beginPath();
              ctx.moveTo(n.x, n.y);
              ctx.lineTo(nodes[j].x, nodes[j].y);
              ctx.stroke();
            }
          }
        });
        requestAnimationFrame(draw);
      };
      draw();
    }
  };

  // =========================================================================
  // ONLINE EXAMINATION SYSTEM CONTROLLER
  // =========================================================================
  const ExamApp = {
    init() {
      ThreeStage.init();
      this.bindEvents();
      this.restoreSession();
    },

    bindEvents() {
      // Login form
      const loginForm = document.getElementById("login-form");
      if (loginForm) {
        loginForm.addEventListener("submit", (e) => {
          e.preventDefault();
          this.handleLogin();
        });
      }

      // Demo student presets
      document.querySelectorAll("[data-preset]").forEach((btn) => {
        btn.addEventListener("click", () => {
          const [name, usn, dept] = btn.getAttribute("data-preset").split("|");
          document.getElementById("student-name").value = name;
          document.getElementById("student-usn").value = usn;
          document.getElementById("student-dept").value = dept;
        });
      });

      // Keyboard navigation during active exam
      window.addEventListener("keydown", (e) => {
        if (state.view !== "exam") return;
        if (e.target && ["INPUT", "TEXTAREA", "SELECT"].includes(e.target.tagName)) return;

        if (e.key === "ArrowRight") {
          this.nextQuestion();
        } else if (e.key === "ArrowLeft") {
          this.prevQuestion();
        } else if (["1", "2", "3", "4"].includes(e.key)) {
          this.selectOption(parseInt(e.key, 10) - 1);
        } else if (["a", "b", "c", "d", "A", "B", "C", "D"].includes(e.key)) {
          const idx = e.key.toLowerCase().charCodeAt(0) - 97;
          this.selectOption(idx);
        } else if (e.key.toLowerCase() === "m") {
          this.toggleFlagCurrent();
        }
      });

      // Proctoring visibility monitor
      document.addEventListener("visibilitychange", () => {
        if (state.view === "exam" && document.hidden) {
          state.tabSwitches += 1;
          const badge = document.getElementById("proctor-warning-count");
          if (badge) {
            badge.textContent = `Focus Warnings: ${state.tabSwitches}`;
            badge.style.color = "#fca5a5";
          }
        }
      });

      // Custom Question Modal Form
      const addQuestionForm = document.getElementById("custom-question-form");
      if (addQuestionForm) {
        addQuestionForm.addEventListener("submit", (e) => {
          e.preventDefault();
          this.saveCustomQuestion();
        });
      }
    },

    restoreSession() {
      try {
        const saved = localStorage.getItem(STORAGE_KEYS.STUDENT);
        if (saved) {
          state.student = JSON.parse(saved);
          this.switchView("dashboard");
          return;
        }
      } catch (e) {
        console.warn(e);
      }
      this.switchView("login");
    },

    handleLogin() {
      const name = document.getElementById("student-name").value.trim();
      const usn = document.getElementById("student-usn").value.trim().toUpperCase();
      const dept = document.getElementById("student-dept").value;

      if (!name || !usn) return;

      state.student = {
        name,
        usn,
        dept,
        loginTime: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })
      };

      localStorage.setItem(STORAGE_KEYS.STUDENT, JSON.stringify(state.student));
      this.switchView("dashboard");
    },

    logout() {
      if (state.view === "exam") {
        if (!confirm("An examination is currently in progress. Are you sure you want to exit?")) {
          return;
        }
        this.stopTimer();
      }
      localStorage.removeItem(STORAGE_KEYS.STUDENT);
      state.student = null;
      this.switchView("login");
    },

    switchView(viewName) {
      state.view = viewName;
      document.querySelectorAll(".view-section").forEach((sec) => {
        sec.classList.toggle("active", sec.id === `view-${viewName}`);
      });

      this.updateTopNav();
      ThreeStage.setStageMode(viewName);

      if (viewName === "dashboard") {
        this.renderDashboard();
      }
    },

    updateTopNav() {
      const navStudent = document.getElementById("nav-student-info");
      const logoutBtn = document.getElementById("nav-logout-btn");
      if (state.student) {
        navStudent.style.display = "flex";
        document.getElementById("nav-student-name").textContent =
          `${state.student.name} (${state.student.usn})`;
        logoutBtn.style.display = "inline-flex";
      } else {
        navStudent.style.display = "none";
        logoutBtn.style.display = "none";
      }
    },

    renderDashboard() {
      const grid = document.getElementById("tracks-grid");
      grid.innerHTML = "";

      window.EXAM_TRACKS.forEach((track) => {
        const card = document.createElement("div");
        card.className = `track-card ${track.id === state.selectedTrackId ? "selected" : ""}`;
        card.onclick = () => this.selectTrack(track.id);
        card.innerHTML = `
          <span class="track-code" style="color:${track.accentHex}">${track.code}</span>
          <div class="track-title">${track.title}</div>
          <div class="track-sub">${track.subtitle}</div>
          <div class="track-meta">
            <span>⏱ ${track.durationMinutes} Mins</span>
            <span>📝 ${track.questions.length} Questions</span>
            <span>🏆 ${track.questions.length * track.marksPerQuestion} Marks</span>
          </div>
        `;
        grid.appendChild(card);
      });

      this.updateSelectedTrackSummary();
      this.renderAttemptHistory();
    },

    selectTrack(trackId) {
      state.selectedTrackId = trackId;
      document.querySelectorAll(".track-card").forEach((c, idx) => {
        const t = window.EXAM_TRACKS[idx];
        c.classList.toggle("selected", t && t.id === trackId);
      });
      this.updateSelectedTrackSummary();
    },

    updateSelectedTrackSummary() {
      const track =
        window.EXAM_TRACKS.find((t) => t.id === state.selectedTrackId) ||
        window.EXAM_TRACKS[0];
      const box = document.getElementById("selected-track-brief");
      if (!box || !track) return;

      box.innerHTML = `
        <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:8px;">
          <span class="badge" style="color:${track.accentHex}">${track.code} Selected</span>
          <span style="font-size:0.78rem; color:var(--text-muted)">Pass Criteria: ${track.passPercentage}%</span>
        </div>
        <h3 style="font-size:1.25rem; margin-bottom:6px;">${track.title}</h3>
        <p style="font-size:0.84rem; color:var(--text-muted); margin-bottom:14px;">
          ${track.subtitle}. Contains ${track.questions.length} objective MCQs (${track.marksPerQuestion} marks each, no negative marking).
        </p>
      `;
    },

    renderAttemptHistory() {
      const tbody = document.getElementById("history-tbody");
      if (!tbody) return;
      const attempts = this.getSavedAttempts();
      if (attempts.length === 0) {
        tbody.innerHTML = `<tr><td colspan="4" style="text-align:center; color:var(--text-muted); padding:16px;">No completed attempts yet. Start an exam to generate results!</td></tr>`;
        return;
      }

      tbody.innerHTML = attempts
        .slice(0, 6)
        .map(
          (a) => `
        <tr>
          <td><strong>${a.trackCode}</strong><br><span style="font-size:0.7rem;color:var(--text-muted)">${a.studentUsn}</span></td>
          <td>${a.score}/${a.maxScore} (${a.percentage}%)</td>
          <td><span class="badge" style="background:${a.passed ? "rgba(16,185,129,0.2)" : "rgba(239,68,68,0.2)"}; color:${a.passed ? "#6ee7b7" : "#fca5a5"}">${a.grade}</span></td>
          <td style="font-size:0.72rem; color:var(--text-muted)">${a.dateStr}</td>
        </tr>
      `
        )
        .join("");
    },

    // =========================================================================
    // START TIMED EXAMINATION
    // =========================================================================
    startExam() {
      const track =
        window.EXAM_TRACKS.find((t) => t.id === state.selectedTrackId) ||
        window.EXAM_TRACKS[0];

      state.activeTrack = track;
      state.currentQuestionIndex = 0;
      state.answers = {};
      state.flagged = {};
      state.visited = { 0: true };
      state.totalSeconds = track.durationMinutes * 60;
      state.remainingSeconds = state.totalSeconds;
      state.isPaused = false;
      state.tabSwitches = 0;
      state.examStartTime = Date.now();

      document.getElementById("exam-track-header").textContent =
        `${track.code}: ${track.title}`;
      document.getElementById("proctor-warning-count").textContent =
        "Focus Warnings: 0";
      document.getElementById("proctor-warning-count").style.color = "#bae6fd";

      ThreeStage.buildExamQuestionNodes(track);
      this.switchView("exam");
      this.renderCurrentQuestion();
      this.renderPalette();
      this.startTimer();
    },

    startTimer() {
      this.stopTimer();
      this.updateTimerDOM();

      state.timerInterval = setInterval(() => {
        if (state.isPaused) return;
        state.remainingSeconds -= 1;
        this.updateTimerDOM();
        ThreeStage.updateTimerVisual(state.remainingSeconds, state.totalSeconds);

        if (state.remainingSeconds <= 0) {
          this.stopTimer();
          this.finalizeAndEvaluate(true);
        }
      }, 1000);
    },

    stopTimer() {
      if (state.timerInterval) {
        clearInterval(state.timerInterval);
        state.timerInterval = null;
      }
    },

    togglePauseTimer() {
      state.isPaused = !state.isPaused;
      const btn = document.getElementById("pause-timer-btn");
      if (btn) {
        btn.textContent = state.isPaused ? "▶ Resume" : "⏸ Pause";
      }
    },

    updateTimerDOM() {
      const mins = Math.floor(Math.max(0, state.remainingSeconds) / 60);
      const secs = Math.max(0, state.remainingSeconds) % 60;
      const formatted = `${String(mins).padStart(2, "0")}:${String(secs).padStart(2, "0")}`;

      const timerDigits = document.getElementById("exam-timer-digits");
      const timerBox = document.getElementById("exam-timer-box");
      if (timerDigits) timerDigits.textContent = formatted;
      if (timerBox) {
        timerBox.classList.toggle("low-time", state.remainingSeconds <= 60);
      }
    },

    renderCurrentQuestion() {
      const track = state.activeTrack;
      if (!track) return;
      const idx = state.currentQuestionIndex;
      const q = track.questions[idx];
      state.visited[idx] = true;

      document.getElementById("q-counter-badge").textContent =
        `Question ${idx + 1} of ${track.questions.length}`;
      document.getElementById("q-topic-badge").textContent = q.topic;
      document.getElementById("q-difficulty-badge").textContent = q.difficulty;
      document.getElementById("q-marks-badge").textContent =
        `+${track.marksPerQuestion} Marks`;
      document.getElementById("question-stem-text").textContent = q.question;

      const optionsContainer = document.getElementById("options-container");
      optionsContainer.innerHTML = "";
      const keys = ["A", "B", "C", "D"];

      q.options.forEach((optText, optIdx) => {
        const isSelected = state.answers[idx] === optIdx;
        const btn = document.createElement("button");
        btn.type = "button";
        btn.className = `option-btn ${isSelected ? "selected" : ""}`;
        btn.onclick = () => this.selectOption(optIdx);
        btn.innerHTML = `
          <span class="option-key">${keys[optIdx] || optIdx + 1}</span>
          <span>${optText}</span>
        `;
        optionsContainer.appendChild(btn);
      });

      const flagBtn = document.getElementById("flag-question-btn");
      if (flagBtn) {
        const isFlagged = !!state.flagged[idx];
        flagBtn.textContent = isFlagged ? "★ Marked for Review" : "☆ Mark for Review";
      }

      document.getElementById("prev-q-btn").disabled = idx === 0;
      const nextBtn = document.getElementById("next-q-btn");
      if (nextBtn) {
        nextBtn.textContent =
          idx === track.questions.length - 1 ? "Review & Submit →" : "Next Question →";
      }

      this.renderPalette();
      ThreeStage.syncQuestionNodeColors();
    },

    selectOption(optIdx) {
      const track = state.activeTrack;
      if (!track) return;
      const q = track.questions[state.currentQuestionIndex];
      if (optIdx < 0 || optIdx >= q.options.length) return;

      state.answers[state.currentQuestionIndex] = optIdx;
      this.renderCurrentQuestion();
    },

    clearCurrentOption() {
      delete state.answers[state.currentQuestionIndex];
      this.renderCurrentQuestion();
    },

    toggleFlagCurrent() {
      const idx = state.currentQuestionIndex;
      state.flagged[idx] = !state.flagged[idx];
      this.renderCurrentQuestion();
    },

    goToQuestion(index) {
      if (!state.activeTrack) return;
      if (index < 0 || index >= state.activeTrack.questions.length) return;
      state.currentQuestionIndex = index;
      this.renderCurrentQuestion();
    },

    nextQuestion() {
      if (!state.activeTrack) return;
      if (state.currentQuestionIndex < state.activeTrack.questions.length - 1) {
        state.currentQuestionIndex += 1;
        this.renderCurrentQuestion();
      } else {
        this.confirmSubmitModal();
      }
    },

    prevQuestion() {
      if (state.currentQuestionIndex > 0) {
        state.currentQuestionIndex -= 1;
        this.renderCurrentQuestion();
      }
    },

    renderPalette() {
      const track = state.activeTrack;
      if (!track) return;
      const grid = document.getElementById("question-palette-grid");
      grid.innerHTML = "";

      let answeredCount = 0;
      let flaggedCount = 0;

      track.questions.forEach((_, idx) => {
        const isCurrent = idx === state.currentQuestionIndex;
        const isAnswered = state.answers[idx] !== undefined;
        const isFlagged = !!state.flagged[idx];

        if (isAnswered) answeredCount++;
        if (isFlagged) flaggedCount++;

        const btn = document.createElement("button");
        btn.type = "button";
        btn.className = [
          "palette-node",
          isCurrent ? "current" : "",
          isAnswered ? "answered" : "",
          isFlagged ? "flagged" : ""
        ]
          .join(" ")
          .trim();
        btn.textContent = idx + 1;
        btn.onclick = () => this.goToQuestion(idx);
        grid.appendChild(btn);
      });

      const total = track.questions.length;
      document.getElementById("palette-summary-stats").textContent =
        `${answeredCount}/${total} Answered • ${flaggedCount} Flagged • ${total - answeredCount} Pending`;
    },

    confirmSubmitModal() {
      const track = state.activeTrack;
      if (!track) return;
      const total = track.questions.length;
      const answered = Object.keys(state.answers).length;
      const unanswered = total - answered;
      const flagged = Object.values(state.flagged).filter(Boolean).length;

      const summaryEl = document.getElementById("submit-modal-summary");
      summaryEl.innerHTML = `
        <div class="kpi-grid" style="margin-top:12px;">
          <div class="kpi-box"><span class="kpi-label">Answered</span><div class="kpi-val" style="color:var(--success)">${answered} / ${total}</div></div>
          <div class="kpi-box"><span class="kpi-label">Unanswered</span><div class="kpi-val" style="color:var(--warning)">${unanswered}</div></div>
          <div class="kpi-box"><span class="kpi-label">Marked for Review</span><div class="kpi-val" style="color:#fcd34d">${flagged}</div></div>
          <div class="kpi-box"><span class="kpi-label">Time Remaining</span><div class="kpi-val">${document.getElementById("exam-timer-digits").textContent}</div></div>
        </div>
      `;
      document.getElementById("submit-confirm-modal").classList.add("open");
    },

    closeSubmitModal() {
      document.getElementById("submit-confirm-modal").classList.remove("open");
    },

    // =========================================================================
    // AUTOMATED OBJECTIVE EVALUATION & RESULT GENERATION
    // =========================================================================
    finalizeAndEvaluate(autoSubmittedByTimer = false) {
      this.closeSubmitModal();
      this.stopTimer();

      const track = state.activeTrack;
      if (!track) return;

      let correctCount = 0;
      let wrongCount = 0;
      let unansweredCount = 0;
      const topicBreakdown = {};

      const itemReviews = track.questions.map((q, idx) => {
        const userChoice = state.answers[idx];
        const isAnswered = userChoice !== undefined;
        const isCorrect = isAnswered && userChoice === q.correctIndex;

        if (!topicBreakdown[q.topic]) {
          topicBreakdown[q.topic] = { correct: 0, total: 0 };
        }
        topicBreakdown[q.topic].total += 1;

        if (!isAnswered) {
          unansweredCount += 1;
        } else if (isCorrect) {
          correctCount += 1;
          topicBreakdown[q.topic].correct += 1;
        } else {
          wrongCount += 1;
        }

        return {
          questionNumber: idx + 1,
          topic: q.topic,
          question: q.question,
          options: q.options,
          userChoice,
          correctIndex: q.correctIndex,
          status: !isAnswered ? "unanswered" : isCorrect ? "correct" : "wrong",
          explanation: q.explanation
        };
      });

      const totalQuestions = track.questions.length;
      const maxScore = totalQuestions * track.marksPerQuestion;
      const score = correctCount * track.marksPerQuestion;
      const percentage = Math.round((score / Math.max(1, maxScore)) * 100);
      const passed = percentage >= track.passPercentage;

      let grade = "F";
      if (percentage >= 90) grade = "S (Outstanding)";
      else if (percentage >= 80) grade = "A (Excellent)";
      else if (percentage >= 65) grade = "B (Good)";
      else if (percentage >= 50) grade = "C (Pass)";

      const timeSpentSeconds = Math.max(
        1,
        state.totalSeconds - Math.max(0, state.remainingSeconds)
      );

      const resultRecord = {
        id: "RES-" + Math.floor(100000 + Math.random() * 900000),
        studentName: state.student ? state.student.name : "Student",
        studentUsn: state.student ? state.student.usn : "USN001",
        studentDept: state.student ? state.student.dept : "CSE",
        trackId: track.id,
        trackCode: track.code,
        trackTitle: track.title,
        score,
        maxScore,
        percentage,
        grade,
        passed,
        correctCount,
        wrongCount,
        unansweredCount,
        totalQuestions,
        timeSpentSeconds,
        tabSwitches: state.tabSwitches,
        autoSubmittedByTimer,
        topicBreakdown,
        itemReviews,
        dateStr: new Date().toLocaleString([], {
          dateStyle: "medium",
          timeStyle: "short"
        })
      };

      state.lastResult = resultRecord;
      this.saveAttemptRecord(resultRecord);
      ThreeStage.buildResults3DBars(resultRecord);
      this.renderResultsView(resultRecord);
      this.switchView("results");
    },

    renderResultsView(res) {
      document.getElementById("res-title-banner").textContent =
        `${res.trackCode}: ${res.trackTitle} — Official Result`;
      document.getElementById("res-student-meta").textContent =
        `${res.studentName} (${res.studentUsn}) • ${res.studentDept} • ${res.dateStr} • ID: ${res.id}`;

      const scoreEl = document.getElementById("res-big-percentage");
      scoreEl.textContent = `${res.percentage}%`;
      scoreEl.style.color = res.passed ? "var(--success)" : "var(--danger)";

      document.getElementById("res-grade-badge").textContent =
        `${res.grade} • ${res.passed ? "PASSED" : "NEEDS IMPROVEMENT"}`;
      document.getElementById("res-grade-badge").style.background = res.passed
        ? "rgba(16, 185, 129, 0.2)"
        : "rgba(239, 68, 68, 0.2)";
      document.getElementById("res-grade-badge").style.color = res.passed
        ? "#6ee7b7"
        : "#fca5a5";

      const mins = Math.floor(res.timeSpentSeconds / 60);
      const secs = res.timeSpentSeconds % 60;

      document.getElementById("res-kpi-score").textContent =
        `${res.score} / ${res.maxScore}`;
      document.getElementById("res-kpi-accuracy").textContent =
        `${res.correctCount} Correct • ${res.wrongCount} Wrong • ${res.unansweredCount} Skipped`;
      document.getElementById("res-kpi-time").textContent =
        `${mins}m ${secs}s ${res.autoSubmittedByTimer ? "(Auto-Timeout)" : ""}`;
      document.getElementById("res-kpi-proctor").textContent =
        `${res.tabSwitches} Focus Switch(es)`;

      // Topic breakdown pills
      const topicEl = document.getElementById("res-topic-breakdown");
      topicEl.innerHTML = Object.entries(res.topicBreakdown)
        .map(([topic, stats]) => {
          const pct = Math.round((stats.correct / stats.total) * 100);
          return `
            <div class="kpi-box">
              <span class="kpi-label">${topic}</span>
              <div class="kpi-val" style="font-size:0.95rem">${stats.correct}/${stats.total} (${pct}%)</div>
            </div>
          `;
        })
        .join("");

      // Question-by-question automated evaluation key
      const reviewContainer = document.getElementById("res-review-list");
      const keys = ["A", "B", "C", "D"];
      reviewContainer.innerHTML = res.itemReviews
        .map((item) => {
          const userAnsText =
            item.userChoice !== undefined
              ? `${keys[item.userChoice]}: ${item.options[item.userChoice]}`
              : "Not Attempted";
          const correctAnsText = `${keys[item.correctIndex]}: ${item.options[item.correctIndex]}`;
          const statusLabel =
            item.status === "correct"
              ? "✓ Correct"
              : item.status === "wrong"
              ? "✗ Incorrect"
              : "○ Unanswered";

          return `
            <div class="review-item ${item.status}">
              <div style="display:flex; justify-content:space-between; margin-bottom:6px; font-size:0.78rem;">
                <strong>Q${item.questionNumber} • ${item.topic}</strong>
                <span>${statusLabel}</span>
              </div>
              <div style="font-size:0.92rem; font-weight:600; margin-bottom:8px;">${item.question}</div>
              <div style="font-size:0.82rem; color:var(--text-muted);">
                <div>Your Answer: <strong style="color:${item.status === "correct" ? "#6ee7b7" : "#fca5a5"}">${userAnsText}</strong></div>
                <div>Correct Answer: <strong style="color:#6ee7b7">${correctAnsText}</strong></div>
              </div>
              <div class="review-explanation">💡 <strong>Evaluation Note:</strong> ${item.explanation}</div>
            </div>
          `;
        })
        .join("");
    },

    exportResultJSON() {
      if (!state.lastResult) return;
      const blob = new Blob([JSON.stringify(state.lastResult, null, 2)], {
        type: "application/json"
      });
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = `${state.lastResult.studentUsn}_${state.lastResult.trackCode}_Result.json`;
      a.click();
      URL.revokeObjectURL(url);
    },

    // =========================================================================
    // FACULTY / CUSTOM QUESTION BUILDER
    // =========================================================================
    openCustomQuestionModal() {
      document.getElementById("custom-question-modal").classList.add("open");
    },

    closeCustomQuestionModal() {
      document.getElementById("custom-question-modal").classList.remove("open");
    },

    saveCustomQuestion() {
      const trackId = document.getElementById("cq-track").value;
      const topic = document.getElementById("cq-topic").value.trim() || "Custom Topic";
      const stem = document.getElementById("cq-stem").value.trim();
      const optA = document.getElementById("cq-opt0").value.trim();
      const optB = document.getElementById("cq-opt1").value.trim();
      const optC = document.getElementById("cq-opt2").value.trim();
      const optD = document.getElementById("cq-opt3").value.trim();
      const correctIndex = parseInt(document.getElementById("cq-correct").value, 10);
      const explanation =
        document.getElementById("cq-explanation").value.trim() ||
        "Verified by Faculty Evaluation Key.";

      if (!stem || !optA || !optB || !optC || !optD) return;

      const track = window.EXAM_TRACKS.find((t) => t.id === trackId);
      if (!track) return;

      const newQ = {
        id: Date.now(),
        topic,
        difficulty: "Medium",
        question: stem,
        options: [optA, optB, optC, optD],
        correctIndex,
        explanation
      };

      track.questions.push(newQ);

      try {
        const raw = localStorage.getItem(STORAGE_KEYS.CUSTOM_QUESTIONS);
        const map = raw ? JSON.parse(raw) : {};
        if (!Array.isArray(map[trackId])) map[trackId] = [];
        map[trackId].push(newQ);
        localStorage.setItem(STORAGE_KEYS.CUSTOM_QUESTIONS, JSON.stringify(map));
      } catch (e) {
        console.warn(e);
      }

      document.getElementById("custom-question-form").reset();
      this.closeCustomQuestionModal();
      this.renderDashboard();
    },

    getSavedAttempts() {
      try {
        const raw = localStorage.getItem(STORAGE_KEYS.ATTEMPTS);
        return raw ? JSON.parse(raw) : [];
      } catch (e) {
        return [];
      }
    },

    saveAttemptRecord(rec) {
      try {
        const list = this.getSavedAttempts();
        list.unshift(rec);
        localStorage.setItem(STORAGE_KEYS.ATTEMPTS, JSON.stringify(list.slice(0, 25)));
      } catch (e) {
        console.warn(e);
      }
    },

    clearHistory() {
      localStorage.removeItem(STORAGE_KEYS.ATTEMPTS);
      this.renderAttemptHistory();
    }
  };

  window.ExamApp = ExamApp;
  window.addEventListener("DOMContentLoaded", () => ExamApp.init());
})();
