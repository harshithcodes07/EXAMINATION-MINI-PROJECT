# NexusExam 3D — Online Examination System (Three.js Miniproject)

An interactive **Online Examination System** web application built with **HTML5, CSS3, JavaScript (ES6+), and Three.js (WebGL)** for conducting timed online examinations, interactive 3D question navigation, and automated evaluation of objective questions.

---

## 🎯 Problem Statement Addressed
> *"Develop a system where students can log in, attend timed examinations, and submit answers online. Automatically evaluate objective questions and generate examination results."*

---

## ✨ Key Features

1. **Student Authentication & Session Portal**:
   - Login with Student Name, University Roll/USN Number, Department, and Access PIN.
   - Includes **1-click Demo Student Presets** for rapid miniproject viva demonstrations.
   - Persists session state and historical exam attempts in `localStorage`.

2. **Interactive Three.js (3D WebGL) Environment**:
   - **3D Subject Polyhedrons**: Each examination paper is represented as a rotating 3D geometric crystal (`Icosahedron`, `Octahedron`, `TorusKnot`, `Dodecahedron`) selectable via `THREE.Raycaster`.
   - **3D Orbital Question Nodes**: During an active exam, every question appears as a 3D node floating in an orbital arc above the HUD. Clicking any 3D node jumps directly to that question.
   - **Live 3D State Encoding**:
     - **Cyan Halo + Enlarged Scale**: Active question
     - **Emerald Green**: Answered question
     - **Amber Gold**: Marked for review
     - **Slate**: Unvisited / unanswered
   - **3D Chrono-Ring Timer**: Central torus ring dynamically shifts color from Cyan → Amber → Crimson as remaining time decreases.
   - **3D Results Analytics Towers**: Displays 3D bar towers comparing Correct, Incorrect, and Unanswered counts.

3. **Timed Examination & Proctoring Engine**:
   - Real-time countdown clock with **automatic submission** when the timer reaches `00:00`.
   - Question palette with **Mark for Review**, **Clear Choice**, and keyboard shortcuts (`1–4` or `A–D` to choose options, `M` to flag, `← / →` to navigate).
   - **Focus / Tab-Switch Detection** using the Page Visibility API.
   - **Faculty Mode**: Add custom objective questions to any track directly from the dashboard.

4. **Automated Objective Evaluation & Result Generation**:
   - Instant grading with total score, percentage, letter grade (`S`, `A`, `B`, `C`, `F`), pass/fail status, and time taken.
   - **Topic-wise Competency Breakdown** and a complete **Question-by-Question Evaluation Key** with explanations.
   - **Print / Save as PDF Scorecard** and **Export JSON Result**.

---

## 🚀 How to Run

1. Open [`index.html`](./index.html) directly in any modern browser (Chrome, Safari, Edge, Firefox), **or**
2. Run a local static server inside this directory:
   ```bash
   python3 -m http.server 8080
   ```
   Then visit `http://localhost:8080`.
